## Available Scripts
In the project, you can run:

### `npm start` or `npm run solution`

It will run the solution.js file and it automatically takes the input from clicks.json file and prints the output into result-set.json

