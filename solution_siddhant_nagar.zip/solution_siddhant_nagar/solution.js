const fs = require('fs')

const getValue = (prev, next) => {
  if (prev.amount === next.amount) {
    return (new Date(prev.timestamp) < new Date(next.timestamp)) ? prev : next;
  }
  return (prev.amount > next.amount) ? prev : next;
}

//Function to count total no of dulpicate IP of unique ip
const countIPAddress = (input) => {
  const obj = {};
  input.forEach((item) => {
    obj[item.ip] = (obj[item.ip] || 0) + 1
  });
  return obj;
}

//It return the array which has 10 or less than 10 clicks for an IP in the overall array of clicks
const getFilteredData = (input, inputCount) => {
  return input.filter((item) => inputCount[item.ip] <= 10)
}

//It set the output result into result-set.json file
const setResult = (resultSet) => {
  fs.writeFile('result-set.json', JSON.stringify(resultSet), (err) => {
    if (err) throw err;
  })
}

//It create final resultset array.
const getResultSet = (periodObj) => {
  let resultSet = [];
  Object.values(periodObj).forEach((item) => {
    resultSet = [...resultSet, ...Object.values(item)]
  })
  setResult(resultSet);
}

//return the period of given item
const getPeriod = (item) => (new Date(item.timestamp).getHours() + 1).toString();

const getData = (filteredData) => {
  const periodObj = {}; //it stores each data which falls under that particular time period where key is timeperiod and value is object 

  //it executes loop and check every individual array value and set the final value in periodObj
  filteredData.forEach((item) => {
    const period = getPeriod(item);
    if (Object.keys(periodObj).includes(period)) {
      if (Object.keys(periodObj[period]).includes(item.ip)) {
        periodObj[period] = { ...periodObj[period], [item.ip]: getValue(periodObj[period][item.ip], item) }
      } else {
        periodObj[period] = { ...periodObj[period], [item.ip]: item }
      }
    } else {
      periodObj[period] = { [item.ip]: item }
    }
  })

  getResultSet(periodObj);
}

const readInputFromFile = () => {
  // To read input from clicks.json file
  fs.readFile('./clicks.json', (err, inputData) => {

    //if error it will throw error
    if (err) throw err;

    //it will parse the array
    const input = JSON.parse(inputData.toString());
    const inputCount = countIPAddress(input); //it stores total IP count corresponding to unique IP
    const filteredData = getFilteredData(input, inputCount);
    getData(filteredData);
  })
}

// call this function to get result
readInputFromFile();